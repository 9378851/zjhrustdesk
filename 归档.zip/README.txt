RustDesk 自定义图标覆盖包 (2026-10-29)
====================================
解压到 rustdesk 源码根目录, 直接覆盖同名文件。

覆盖清单:
  res/icon.ico                                          -> Windows 主程序/安装器图标
  res/tray-icon.ico                                     -> Windows/Linux 托盘图标 (编译期嵌入, 需 clean 重编)
  res/icon.png                                          -> 主源图 (1024x1024)
  flutter/windows/runner/resources/app_icon.ico          -> Flutter Windows 启动图标 (编译期嵌入)
  flutter/macos/Runner/Assets.xcassets/AppIcon.appiconset/AppIcon.icns -> macOS 应用图标

注意:
1. macOS 托盘 (res/mac-tray-*.png) 保持原样, 不要覆盖。
2. macOS appiconset 里的 Contents.json 不要动。
3. tray-icon.ico 与 app_icon.ico 为编译期嵌入, 覆盖后需 clean 后重新编译。
